# Changelog

## 1.0.0

- Preserve the 0.2.2 host integration API, namespace, runtime dependencies and minimum Android API 26. Host apps continue to own all UI and installation consent.
- Validate the downloaded APK’s signer before inspecting its manifest resources. Grant the verified APK to an explicit system installation handler.
- Preserve settings during download progress, retry transient background checks, and bind queued downloads to their selected channel and tag. Refresh the ready state when the asset digest or size changes.
- Reject malformed feed digests, correct prerelease ordering, and validate portable filenames during bundle export.

## 0.2.0 — 2026-10-24 (prerelease)

- Replace the personal-domain package and Maven group with `io.github.phillip9933`.
- Remove application-specific references from the README and use GitHub private vulnerability reporting.
- Breaking change: update imports and dependency coordinates. Updater bootstrap registration uses a new preference namespace; call initialize after upgrading. Previously published versions and Git history are preserved.
- Harden SDK export: reject dirty/untracked source, export committed files only, build artifacts from the same isolated snapshot, validate Maven identity and record the source revision.
- Reject release JSON with incorrect field types. Add hostile URL/redirect, signer-set, forged/unsigned APK and installer revalidation regressions. Align the wrapper JAR with the pinned Gradle 8.13 distribution.

## 0.1.3 — 2026-10-24

Security fix: read debuggable status from the APK binary manifest as well as PackageManager flags. Android 15 may return zero archive flags, which allowed a same-signer debug APK through the previous check. Resolve boolean resources and fail closed on unreadable or invalid application metadata. Add a portable native verifier test app with generated, disposable debug-signed fixtures. Version 0.1.2 is superseded; adopt 0.1.3 before app-release acceptance.


## 0.1.2 — 2026-10-24

First public SDK prerelease of the standalone updater extracted from Raiun. Includes explicit app feed configuration, strict GitHub origin/download verification, installed-app identity checks, opt-in host policy controls, background check/download support and foreground installer handoff. Adds independent project guidance, security/contribution/release documentation and quality CI. Signed API 26/API 35/physical-device upgrade acceptance remains pending.

0.1.0 and 0.1.1 were local development bundles; their existing consumers and bytes are preserved.
